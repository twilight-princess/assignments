import React from 'react'

function Avatar(props) {
    return (
        <div>
            <img src={props.userImg} alt=""/>
        </div>
    )
}

export default Avatar
